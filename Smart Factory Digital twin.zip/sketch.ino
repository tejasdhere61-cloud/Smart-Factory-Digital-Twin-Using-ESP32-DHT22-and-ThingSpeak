#include <WiFi.h>
#include <HTTPClient.h>
#include <DHTesp.h>

// WiFi for Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Put YOUR ThingSpeak Write API Key here
String apiKey = "OXCG545TXBAFD8F0";

// Pin connections
const int DHT_PIN = 15;
const int VIBRATION_PIN = 34;

const int MOTOR_LED = 26;
const int WARNING_LED = 27;

// DHT sensor
DHTesp dhtSensor;

void setup() {

  Serial.begin(115200);

  // DHT22 setup
  dhtSensor.setup(DHT_PIN, DHTesp::DHT22);

  // LED setup
  pinMode(MOTOR_LED, OUTPUT);
  pinMode(WARNING_LED, OUTPUT);

  Serial.println("Smart Factory Digital Twin Started");

  // Connect WiFi
  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected!");
}

void loop() {

  // Read DHT22
  TempAndHumidity data = dhtSensor.getTempAndHumidity();

  float temperature = data.temperature;
  float humidity = data.humidity;

  // Read potentiometer
  int vibration = analogRead(VIBRATION_PIN);

  // Machine status
  int machineStatus;

  if (vibration > 2000) {

    digitalWrite(MOTOR_LED, HIGH);
    digitalWrite(WARNING_LED, HIGH);

    machineStatus = 1;

    Serial.println("WARNING: High Vibration!");

  } else {

    digitalWrite(MOTOR_LED, HIGH);
    digitalWrite(WARNING_LED, LOW);

    machineStatus = 0;

    Serial.println("Machine Normal");
  }

  // Serial Monitor Output
  Serial.println("----------------------------");

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  Serial.print("Vibration: ");
  Serial.println(vibration);

  Serial.print("Machine Status: ");
  Serial.println(machineStatus);

  // Send data to ThingSpeak
  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    String url = "http://api.thingspeak.com/update?api_key=" + apiKey +
                 "&field1=" + String(temperature) +
                 "&field2=" + String(humidity) +
                 "&field3=" + String(vibration) +
                 "&field4=" + String(machineStatus);

    http.begin(url);

    int httpResponseCode = http.GET();

    Serial.print("ThingSpeak Response: ");
    Serial.println(httpResponseCode);

    http.end();

  } else {

    Serial.println("WiFi Disconnected!");

  }

  // ThingSpeak requires waiting between updates
  delay(20000);
}